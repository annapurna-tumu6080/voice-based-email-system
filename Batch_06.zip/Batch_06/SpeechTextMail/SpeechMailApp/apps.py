from django.apps import AppConfig


class SpeechmailappConfig(AppConfig):
    name = 'SpeechMailApp'
